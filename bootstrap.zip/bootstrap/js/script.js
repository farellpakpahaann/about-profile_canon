function scrollToTop() {
    window.scrollTo({
      top: 0,
      behavior: 'smooth' // Optional smooth scrolling
    });
  }

// Mendapatkan elemen navbar yang akan dijadikan sticky
var navbar = document.getElementById("stickyNavbar");

// Mendapatkan posisi navbar dari atas dokumen
var navbarOffset = navbar.offsetTop;

// Fungsi untuk menambahkan class 'sticky' ke navbar saat melakukan scroll
function stickyNavbar() {
    if (window.pageYOffset >= navbarOffset) {
        navbar.classList.add("sticky");
    } else {
        navbar.classList.remove("sticky");
    }
}

// Menjalankan fungsi stickyNavbar saat melakukan scroll
window.onscroll = function () {
    stickyNavbar();
};

// validasi form
function validateForm() {
  var name = document.forms["myForm"]["name"].value;
  var email = document.forms["myForm"]["email"].value;
  var phone = document.forms["myForm"]["phone"].value;

  if (name === "" || email === "" || phone === "") {
      alert("All fields must be filled out");
      return false;
  }

  var emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!emailRegex.test(email)) {
      alert("Please enter a valid email address");
      return false;
  }

  var phoneRegex = /^\d{10}$/;
  if (!phone.match(phoneRegex)) {
      alert("Please enter a 10-digit phone number");
      return false;
  }

  return true;
}

// Clock
function digitalClock(){
    let dateFunction = new Date()
    let day = dateFunction.getDay()
    let hours = dateFunction.getHours()
    let minutes = dateFunction.getMinutes()
    let seconds = dateFunction.getSeconds()
    let timeFormat = 'AM'

    timeFormat = hours >= 12 ? 'PM' : 'AM'
    hours = hours == 0 ? 12 : hours
    hours = hours > 12 ? hours - 12 : hours
    hours = hours < 10 ? '0' + hours : hours
    minutes = minutes < 10 ? '0' + minutes : minutes
    seconds = seconds < 10 ? '0' + seconds : seconds

    document.querySelector('.hours').innerHTML = hours
    document.querySelector('.minutes').innerHTML = minutes
    document.querySelector('.seconds').innerHTML = seconds
    document.querySelector('.format').innerHTML = timeFormat

    let todaysDay = document.querySelector(`.weekdays :nth-child(${day + 1})`)
    todaysDay.classList.add('active')
}
setInterval(digitalClock, 1000)
